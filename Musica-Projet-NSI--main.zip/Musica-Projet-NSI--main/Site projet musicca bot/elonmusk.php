<html>



<head>

	<title> Elon Musk </title>
	
</head>



<body>

	<body bgcolor="#32BA09">
		
		<font face="Tahoma">
		
		
	<?php
		if (($_GET['login']=="admin")&&($_GET['motpasse']=="elonmusk"))
		
		else
				echo "Vous n'avez pas accès à la page";
			
			
			?>
			
	